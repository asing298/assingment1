import { Injectable } from '@angular/core';
import { Merchant } from './merchant';

import { HttpClientModule } from '@angular/common/http'; 



import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';



//const headers= new HttpHeaders({ 'Content-Type':'application/json'});

@Injectable({
  providedIn: 'root'
})
export class MerchantService {
	path = '../assets/merchant.json';
	
	constructor(private http:HttpClient) { 
	
	}
	getData():Observable<Merchant[]>{
		return this.http.get<Merchant[]>(this.path);
	}

}
