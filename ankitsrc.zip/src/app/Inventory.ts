export class Inventory{
   
    inventoryId:number;
    merchantId:number;
    productName:string;
    productCategory:string;
    productPrice:number;
    productDescription:string;
    promoId:number;
    status:string;
    inventoryType:string;
    inventoryQuantity:number;
   
}