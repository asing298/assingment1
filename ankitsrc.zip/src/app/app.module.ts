import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminMainPageComponent } from './admin-main-page/admin-main-page.component';
import { MerchantComponent } from './merchant/merchant.component';
import { ProductComponent } from './products/products.component';
import { CustomersComponent } from './customers/customers.component';
import { PromosComponent } from './promos/promos.component';

import { MerchantService } from './merchant-service.service';
import { ProductService } from './product-service.service';
import { CustomerService } from './customer.service';



@NgModule({
  declarations: [
    AppComponent,
    AdminMainPageComponent,
    MerchantComponent,
    ProductComponent,
    CustomersComponent,
    PromosComponent,

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
	FormsModule
    
  ],
  providers: [ MerchantService ,ProductService, CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { 

}
